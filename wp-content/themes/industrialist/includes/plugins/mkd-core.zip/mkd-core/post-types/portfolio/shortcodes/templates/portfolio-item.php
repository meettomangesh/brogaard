<article class="mkd-pl-item <?php echo esc_attr($article_class); ?>">
	<div class="mkd-pl-item-inner">
		<?php echo mkd_core_get_shortcode_module_template_part('portfolio', 'layout-collections/'.$item_layout, '', $params); ?>
	</div>
</article>