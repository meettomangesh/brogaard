<div class="mkd-clients-table-item-holder">
    <?php if ($link !== '') { ?>
    <a href="<?php echo esc_url($link) ?>" target="<?php echo esc_attr($target) ?>">
        <?php } ?>
        <?php if ($image !== '') { ?>
            <span class="mkd-clients-table-first-image-holder <?php echo esc_attr($hover_class); ?>">
				<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_html($title); ?>">
			</span>
        <?php } ?>
        <?php if ($hover_image !== '') { ?>
            <span class="mkd-clients-table-second-image-holder <?php echo esc_attr($hover_class); ?>">
				<img src="<?php echo esc_url($hover_image); ?>" alt="<?php echo esc_html($title); ?>">
			</span>
        <?php } ?>
        <?php if ($link !== '') { ?>
    </a>
<?php } ?>
</div>